import { expect, test } from 'vitest'

test('1 + 1 は 2 になること', () => {
  expect(1 + 1).toBe(2)
})